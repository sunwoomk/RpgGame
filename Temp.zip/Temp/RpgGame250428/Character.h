#pragma once

class Character 
{
public:
	Character();
	Character(string name, int attackPower, int defencePower, int healthPoint, int speed);
	~Character();

	string GetName() { return name; }
	int GetAttackPower() { return attackPower; }
	int GetDefencePower() { return defencePower; }
	int GetHealthPoint() { return healthPoint; }
	int GetSpeed() { return speed; }
	int GetShield() { return shield; }

	void TakeDamage(int dmg)
	{
		int effectiveDmg = max(dmg - shield, 0);
		healthPoint -= effectiveDmg;
		if (healthPoint < 0) healthPoint = 0;
	}

private:
	string name = "";
	int attackPower = 0;
	int defencePower = 0;
	int healthPoint = 0;
	int speed = 0;
	int shield = 0;
};

