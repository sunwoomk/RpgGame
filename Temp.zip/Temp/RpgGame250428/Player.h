#pragma once

class Player : public Character
{
public:
	Player();
	Player(string name, int attackPower, int defencePower, int healthPoint, int speed);
	~Player();
};
