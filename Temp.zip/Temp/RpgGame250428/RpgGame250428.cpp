﻿#include "Framework.h"

enum GameState
{
	Setting,
	PlayerTurn,
	MonsterTurn,
	Clear,
	GameOver
};

int main()
{

}
