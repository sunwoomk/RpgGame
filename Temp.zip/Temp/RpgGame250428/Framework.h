#pragma once

#include <iostream>
#include <string>

using namespace std;

#include "Character.h"
#include "Player.h"
#include "Warrior.h"
#include "Magician.h"
#include "Priest.h"
