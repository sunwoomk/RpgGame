#include "Framework.h"

Magician::Magician() : Player("������", 300, 50, 50, 80)
{

}

Magician::~Magician()
{

}
