#include "Framework.h"

Warrior::Warrior() : Player("����", 100, 300, 300, 50)
{

}

Warrior::~Warrior()
{

}
