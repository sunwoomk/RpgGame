#include "Framework.h"

Player::Player()
{

}

Player::Player(string name, int attackPower, int defencePower, int healthPoint, int speed)
{

}

Player::~Player()
{

}
