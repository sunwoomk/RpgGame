#pragma once

class Priest : public Player 
{
public:
	Priest();
	~Priest();
};
