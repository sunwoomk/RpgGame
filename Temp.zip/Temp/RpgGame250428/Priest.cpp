#include "Framework.h"

Priest::Priest() : Player("����", 50, 200, 200, 100)
{

}

Priest::~Priest()
{

}
