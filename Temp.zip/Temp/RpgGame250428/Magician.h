#pragma once

class Magician : public Player
{
public:
	Magician();
	~Magician();
};
