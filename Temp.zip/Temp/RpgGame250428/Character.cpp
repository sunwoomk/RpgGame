#include "Framework.h"

Character::Character()
{

}

Character::Character(string name, int attackPower, int defencePower, int healthPoint, int speed)
{

}

Character::~Character()
{

}
