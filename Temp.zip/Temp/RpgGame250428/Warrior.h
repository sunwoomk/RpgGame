#pragma once

class Warrior : public Player 
{
public:
	Warrior();
	~Warrior();
};